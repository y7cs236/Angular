/**
 * Created by kalyan on 15-04-2016.
 */
'use strict';
eventsApp.factory('EventsData',function ($http,$log) {
    return{
      getEvent:function (successcb) {
          $http({method:"GET", url: '/data/event/5'}).
              success(function (data, status, headers,config) {
              successcb(data);
          }).
              error(function(data, status, headers,config){
              $log.warn(data, status, headers(),config);
          });
      }
    };
});   