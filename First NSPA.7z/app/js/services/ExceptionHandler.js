/**
 * Created by kalyan on 17-04-2016.
 */
'use strict';
eventsApp.factory('$exceptionHandler', function (exception) {
  console.log(exception);
});