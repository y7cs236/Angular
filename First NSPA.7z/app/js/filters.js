/**
 * Created by kalyan on 08-04-2016.
 */
'use strict';

eventsApp.filter('Duration',function () {
    return function (input) {
        var output;
        switch (input){
            case 1:
               output = "One Hour";
                break;
            case 2:
               output = "Two Hour";
                break;
            case 3:
                output = "Four Hour";
                break;
            case 4:
                output = "Half Day";
                break;
            case 6:
               output= "Full Day";
                break;
        }
        return output;
    }
});