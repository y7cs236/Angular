/**
 * Created by kalyan on 17-04-2016.
 */
eventsApp.controller('TimeoutController', function ($scope,$timeout) {

    var promise=$timeout(function () {
        $scope.name="kalyan";
    },3000);

    $scope.cancel=function(){
        $timeout.cancel(promise);
    };
});