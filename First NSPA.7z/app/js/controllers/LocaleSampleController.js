/**
 * Created by kalyan on 17-04-2016.
 */
"use strict";
eventsApp.controller('LocaleController',function ($scope,$locale) {
    console.log($locale);

    $scope.myDate= Date.now();
    $scope.myFormat= $locale.DATETIME_FORMATS.fullDate;

    
});