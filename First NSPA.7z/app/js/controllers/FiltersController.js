/**
 * Created by kalyan on 17-04-2016.
 */
'use strict';
eventsApp.controller('FilterController',
    function FilterController($scope,DurationFilter) {

    $scope.data={};

    $scope.data.duration1= DurationFilter(1);
    $scope.data.duration2= DurationFilter(2);
    $scope.data.duration3= DurationFilter(3);
    $scope.data.duration4= DurationFilter(4);
});