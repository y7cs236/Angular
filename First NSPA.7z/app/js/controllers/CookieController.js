/**
 * Created by kalyan on 17-04-2016.
 */

eventsApp.controller('CookieController',
    function CookieController($scope, $cookieStore) {

        $scope.name = "kalyan";
        $scope.event = {id: 1, name: 'kalyan'};
        $scope.SaveCookie = function (event) {
            $cookieStore.put('event', event);
        };

        $scope.GetCookie = function () {
            console.log($cookieStore.get("event"));
        };

        $scope.RemoveCookie = function () {
            $cookieStore.remove("event");
        };
    }
);