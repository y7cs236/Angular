"use strict";

eventsApp.controller('eventCtrl',
    function ($scope) {

        $scope.snippet = '<div style="color:#ff0e18">hi there</div>';
        $scope.sortOrder = 'name';
        $scope.boolvalue = true;
        $scope.message = 'test';
        $scope.mystyle = {color: 'red'};
        $scope.myclass = "blue";
        $scope.buttonDisabled = true;

        $scope.event = {
            name: 'Angular boot Camp',
            Date: 1359781015626,
            Time: '11:30',
            Address: {
                City: 'Hyderabad',
                PinCode: '500084'
            },
            ImageUrl: '../img/angularjs-logo.png',
            Sessions: [
                {
                    name: 'Mastering Web API',
                    CreatorName: 'Gopala Krishna',
                    Duration: 1,
                    level: 'Advanced',
                    VoteCount: 8
                },
                {
                    name: 'Programming with WCF',
                    CreatorName: 'udayagiri  kalayn',
                    Duration: 2,
                    level: 'Beginner',
                    VoteCount: 2
                },
                {
                    name: 'Jquery Guide',
                    CreatorName: 'Gopala Krishna',
                    Duration: 6,
                    level: 'Advanced',
                    VoteCount: 6
                }

            ]
        };
        $scope.upVotesession = function (session) {
            session.VoteCount++;
        }
        $scope.DownVotesession = function (session) {
            session.VoteCount--;
        }
    }
);